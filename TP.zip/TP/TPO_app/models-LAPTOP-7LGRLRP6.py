from django.db import models

# Create your models here.

class Student(models.Model):
    COURSE_CHOICES = [
        ('AI', 'Artificial Intelligence'),
        ('ML', 'Machine Learning'),
        ('DS', 'Data Science'),
        ('DB', 'Database Systems'),
        ('CS', 'Cyber Security'),
        ('CN', 'Computer Networks'),
        ('OS', 'Operating Systems'),
        ('SE', 'Software Engineering'),
    ]
    
    name = models.CharField(max_length=100)
    email = models.EmailField(unique=True)
    phone_number = models.CharField(max_length=15)
    skills = models.TextField(help_text="List of skills, separated by commas.")
    experience = models.TextField(help_text="Any relevant experience.")
    cgpa = models.DecimalField(max_digits=4, decimal_places=2)
    course_subdomain = models.CharField(max_length=2, choices=COURSE_CHOICES, default='AI')

    def __str__(self):
        return self.name
    
class StudentInfo(models.Model):
    uname = models.CharField(max_length=200, default='')
    email = models.CharField(max_length=200)
    phoneno = models.CharField(max_length=200)
    event = models.CharField(max_length=20)
    
    def __str__(self):
        return self.uname

class JobInfo(models.Model):
    uname = models.CharField(max_length=200, default='')
    email = models.CharField(max_length=200)
    phoneno = models.CharField(max_length=200)
    college = models.CharField(max_length=20)
    graduation = models.DecimalField(max_digits=19, decimal_places=2)
    company = models.CharField(max_length=200)
    profile = models.CharField(max_length=200)

    def __str__(self):
        return self.company
        
class EventInfo(models.Model):
    eventname = models.CharField(max_length=200)
    description = models.CharField(max_length=200)
    eventdate = models.CharField(max_length=200)
    
    def __str__(self):
        return self.eventname

class CompanyInfo(models.Model):
    cname = models.CharField(max_length=200)
    role = models.CharField(max_length=200)
    salary = models.CharField(max_length=200)
    
    def __str__(self):
        return self.cname

