from django.contrib import admin # type: ignore
from .models import StudentInfo, JobInfo, EventInfo, CompanyInfo, Student

# Register your models here.
admin.site.register(StudentInfo)
admin.site.register(JobInfo)
admin.site.register(EventInfo)
admin.site.register(CompanyInfo)

class StudentAdmin(admin.ModelAdmin):
    list_display = ('id', 'name', 'email', 'cgpa', 'course_subdomain')
    search_fields = ['name', 'email']
    list_filter = ['course_subdomain']

admin.site.register(Student, StudentAdmin)