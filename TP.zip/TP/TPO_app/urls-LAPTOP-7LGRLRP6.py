from django.contrib import admin
from django.urls import path
from . import views

urlpatterns = [

    path('students/<int:id>/edit/', views.edit_student, name='edit_student'),
    path('delete_student/<int:id>/', views.delete_student, name='delete_student'),
    
    # Home Page
    path('', views.index, name="index"),

    # Authentication
    path('register/', views.register_page, name="register_page"),
    path('login/', views.login_request, name='login'),
    path('logout/', views.logout_request, name='logout'),

    # Student Management
    path('students/', views.students_list, name='students_list'),  # View all students
    path('add_student/', views.add_student, name='add_student'),  # Admin-only student addition

    # Student Registration (for events)
    path('TPO_app/', views.register_student, name="register_student"),
    path('register_student_submit/', views.register_student_submit, name="register_student_submit"),

    # Job Registration
    path('register_job/', views.register_job, name="register_job"),
    path('register_job_submit/', views.register_job_submit, name="register_job_submit"),

    # Companies
    path('companies/', views.companies_list, name="companies_list"),
    path('add_company/', views.add_company, name="add_company"),
    path('add_company_submit/', views.add_company_submit, name="add_company_submit"),

    # Events
    path('upcoming_events/', views.upcoming_events, name="upcoming_events"),
    path('upcoming_events_submit/', views.upcoming_events_submit, name="upcoming_events_submit"),

    # Placement Statistics
    path('Statistics/', views.Statistics, name="Statistics"),

    # Machine Learning - Clustering & Recommendation (Admin Only)
    path('cluster_students/', views.cluster_students_view, name='cluster_students'),
    path('suggest_companies/<int:student_id>/', views.suggest_companies_view, name='suggest_companies'),

    # Success Page
    path('student_success/', views.student_success, name='student_success'),

    # Django Admin Panel
    path('admin/', admin.site.urls),



]
