from django.shortcuts import render, redirect
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm  # type: ignore
from django.contrib.auth.models import User  # type: ignore
from .forms import RegisterForm
from django.contrib import messages  # type: ignore
from django.contrib.auth import login, logout, authenticate
from django.contrib.auth.decorators import login_required
from .models import StudentInfo, JobInfo, EventInfo, CompanyInfo
from . import views
from .forms import StudentForm
from .models import Student
from .ml_model import vectorize_skills_and_cluster, recommend_companies
from django.contrib.admin.views.decorators import staff_member_required
from django.shortcuts import get_object_or_404

# Check if the user is an admin
def is_admin(user):
    return user.is_staff

def index(request):
    """ Render the home page. """
    return render(request, 'includes/index.html')

# ==============================
# Student Management Views
# ==============================

@login_required
def students_list(request):
    """ Display a list of all students. """
    students = Student.objects.all()
    return render(request, 'students_list.html', {'students': students})

@staff_member_required  # Restrict access to admins only
def add_student(request):
    """ Allow only admin to add a new student. """
    if request.method == 'POST':
        form = StudentForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, "Student added successfully!")
            return redirect('students_list')
    else:
        form = StudentForm()
    return render(request, 'TPO_app/add_student.html', {'form': form})

@staff_member_required  # Restrict access to admins only
def edit_student(request, id):
    """ Allow only admin to edit a student's details. """
    student = get_object_or_404(Student, id=id)
    if request.method == 'POST':
        form = StudentForm(request.POST, instance=student)
        if form.is_valid():
            form.save()
            messages.success(request, "Student details updated successfully!")
            return redirect('students_list')
    else:
        form = StudentForm(instance=student)
    return render(request, 'TPO_app/edit_student.html', {'form': form, 'student': student})

@staff_member_required  # Restrict access to admins only
def delete_student(request, id):
    """ Allow only admin to delete a student. """
    student = get_object_or_404(Student, id=id)
    student.delete()
    messages.success(request, "Student deleted successfully!")
    return redirect('students_list')

# ==============================
# Student Registration Views
# ==============================

def register_page(request):
    """ Allow users to register an account. """
    if request.method == 'POST':
        form = RegisterForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'You are successfully registered.')
            return redirect("/")
    else:
        form = RegisterForm()
        
    return render(request, "registration/register.html", {"form": form})

def login_request(request):
    """ Handle user login. """
    if request.method == "POST":
        form = AuthenticationForm(request, request.POST)
        if form.is_valid():
            username = form.cleaned_data.get("username")
            password = form.cleaned_data.get("password")
            user = authenticate(username=username, password=password)
            if user is not None:
                login(request, user)
                messages.info(request, f"You are now logged in as {username}")
                return redirect("/")
            else:
                messages.error(request, "Invalid username or password")
        else:
            messages.error(request, "Invalid username or password")
    form = AuthenticationForm()
    return render(request, "registration/login.html", {"form": form})

@login_required
def logout_request(request):
    """ Logout the user and redirect to home page. """
    logout(request)
    messages.info(request, "Logged out successfully!")
    return redirect("/")

# ==============================
# Student Info Management
# ==============================

@login_required(login_url='/login/')
def register_student(request):
    """ Render the student registration page. """
    return render(request, 'TPO_app/register_student.html')

@login_required(login_url='/login/')
def register_student_submit(request):
    """ Handle student event registration submission. """
    name = request.POST['name']
    email = request.POST['email']
    phoneno = request.POST['phoneno']
    event = request.POST['event']

    Student_Info = StudentInfo(uname=name, email=email, phoneno=phoneno, event=event)
    Student_Info.save()
    messages.success(request, 'You have successfully registered.')
    
    return render(request, 'TPO_app/register_student.html')

# ==============================
# Job Registration Views
# ==============================

@login_required(login_url='/login/')
def register_job(request):
    """ Render the job registration page. """
    return render(request, 'includes/register_job.html')

@login_required(login_url='/login/')
def register_job_submit(request):
    """ Handle job application submission. """
    name = request.POST['name']
    email = request.POST['email']
    phoneno = request.POST['phoneno']
    college = request.POST['college']
    graduation = request.POST['graduation']
    company = request.POST['company']
    profile = request.POST['profile']

    Job_Info = JobInfo(uname=name, email=email, phoneno=phoneno, college=college, 
                       graduation=graduation, company=company, profile=profile)
    Job_Info.save()
    messages.success(request, 'Your Application is successfully sent.')
    
    return render(request, 'includes/register_job.html')

# ==============================
# Event Management Views
# ==============================

def upcoming_events(request):
    """ Render upcoming events page. """
    return render(request, 'includes/upcoming_events.html')

def upcoming_events_submit(request):
    """ Handle event creation. """
    eventname = request.POST['eventname']
    description = request.POST['description']
    eventdate = request.POST['eventdate']

    Event_Info = EventInfo(eventname=eventname, description=description, eventdate=eventdate)
    Event_Info.save()
    messages.success(request, 'Your Event is successfully saved.')
    
    return render(request, 'includes/upcoming_events.html')

# ==============================
# Company Management Views
# ==============================

def add_company(request):
    """ Render company addition form. """
    return render(request, 'includes/add_company.html')

def add_company_submit(request):
    """ Handle new company submission. """
    cname = request.POST['cname']
    role = request.POST['role']
    salary = request.POST['salary']

    Company_Info = CompanyInfo(cname=cname, role=role, salary=salary)
    Company_Info.save()
    messages.success(request, 'Your Company is successfully saved.')
    
    return render(request, 'includes/add_company.html')

# ==============================
# Machine Learning-Based Student Clustering
# ==============================

@staff_member_required
def cluster_students_view(request):
    """ Cluster students based on their skills using ML. """
    students = Student.objects.all()
    
    # Vectorize the skills and perform clustering
    labels, kmeans, vectorizer = vectorize_skills_and_cluster(students)
    
    # Update student clusters in the database
    for student, label in zip(students, labels):
        student.cluster_label = label
        student.save()

    return render(request, 'TPO_app/students_list.html', {'students': students})

@staff_member_required
def suggest_companies_view(request, student_id):
    """ Recommend companies based on student skills using ML. """
    student = get_object_or_404(Student, id=student_id)
    
    # Recommend companies based on the student's skills
    recommended_companies = recommend_companies(student.skills, companies)
    
    return render(request, 'TPO_app/recommended_companies.html', {
        'student': student,
        'recommended_companies': recommended_companies
    })

# ==============================
# Miscellaneous Views
# ==============================

def Statistics(request):
    """ Render placement statistics page. """
    return render(request, 'includes/Statistics.html')

def student_success(request):
    """ Render student success page after successful form submission. """
    return render(request, 'student_success.html')


def companies(request):
    """ Render a list of all companies. """
    companies = CompanyInfo.objects.all()  # Fetch all companies from the database
    return render(request, 'TPO_app/companies_list.html', {'companies': companies})

def companies_list(request):
    """ View to display the list of companies. """
    companies = CompanyInfo.objects.all()  # Fetch all companies from the database
    return render(request, 'TPO_app/companies_list.html', {'companies': companies})
