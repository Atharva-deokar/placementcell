# TPO_app/ml_model.py

from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.cluster import KMeans
import numpy as np

# Function to vectorize the skills and perform clustering
def vectorize_skills_and_cluster(students):
    skills_data = [student.skills for student in students]  # Extract skills from students
    
    # Vectorize the skills using TF-IDF
    vectorizer = TfidfVectorizer(stop_words='english')
    X = vectorizer.fit_transform(skills_data)
    
    # Perform KMeans clustering
    kmeans = KMeans(n_clusters=2, random_state=42)  # 5 clusters, adjust as needed
    labels = kmeans.fit_predict(X)
    
    return labels, kmeans, vectorizer


companies = {
    'Company A': ['Python', 'Data Science', 'Machine Learning'],
    'Company B': ['JavaScript', 'React', 'Node.js'],
    'Company C': ['SQL', 'Tableau', 'Data Analysis'],
    'Company D': ['Java', 'Spring Boot'],
    # Add more companies and skills
}

def recommend_companies(student_skills, companies):
    # Vectorize student's skills
    vectorizer = TfidfVectorizer(stop_words='english')
    student_vector = vectorizer.fit_transform([student_skills])
    
    company_scores = {}
    for company, required_skills in companies.items():
        company_skills_str = ', '.join(required_skills)
        company_vector = vectorizer.transform([company_skills_str])
        
        # Compute similarity (using cosine similarity here)
        similarity = np.dot(student_vector, company_vector.T).toarray()[0][0]
        company_scores[company] = similarity
    
    # Sort companies by similarity score
    recommended_companies = sorted(company_scores.items(), key=lambda x: x[1], reverse=True)
    return recommended_companies